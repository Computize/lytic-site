/********************************************************************************
*This table-valued function returns one row with info about the current server.
(works in SQL 2005 and 2008)
This is included strictly to feed a header in the included reports.
**********************************************************************************/

IF OBJECT_ID (N'dbo.ufnServerInfo', N'IF') IS NOT NULL
    DROP FUNCTION dbo.ufnServerInfo
GO

ALTER FUNCTION dbo.ufnServerInfo()

/****************Computize! Consulting, Inc., copyright, 2010*****************/
/****************Published June, 2012 *****************/
/*********from http://www.computizeconsulting.com by Edward Heraux*****************/

RETURNS TABLE
AS
RETURN
--Grab server name and version info
SELECT SERVERPROPERTY('servername') AS ServerName
	, @@Version as SQLServerVersion
	, CONVERT(VARCHAR(100), serverproperty('Edition')) AS Edition
	, SERVERPROPERTY('productversion')AS Version

	, SERVERPROPERTY ('productlevel') AS ProductLevel
	,CONVERT(VARCHAR(100), SERVERPROPERTY ('LicenseType')) AS LicenseType
	
GO

SELECT * FROM dbo.ufnServerInfo()